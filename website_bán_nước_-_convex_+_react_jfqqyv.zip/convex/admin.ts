import { query, mutation, action } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Kiểm tra quyền admin (tạm thời bỏ yêu cầu đăng nhập)
async function requireAdmin(ctx: any) {
  const userId = await getAuthUserId(ctx);
  // Tạm thời bỏ yêu cầu đăng nhập để dễ dàng truy cập admin
  return userId || "anonymous";
}

// Dashboard thống kê
export const getDashboardStats = query({
  args: {},
  handler: async (ctx) => {
    await requireAdmin(ctx);

    const totalProducts = await ctx.db.query("products").collect();
    const totalOrders = await ctx.db.query("orders").collect();
    const totalCategories = await ctx.db.query("categories").collect();
    const totalUsers = await ctx.db.query("users").collect();

    // Tính doanh thu
    const completedOrders = totalOrders.filter(order => order.orderStatus === "delivered");
    const totalRevenue = completedOrders.reduce((sum, order) => sum + order.finalAmount, 0);

    // Đơn hàng theo trạng thái
    const ordersByStatus = totalOrders.reduce((acc, order) => {
      acc[order.orderStatus] = (acc[order.orderStatus] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      totalProducts: totalProducts.length,
      totalOrders: totalOrders.length,
      totalCategories: totalCategories.length,
      totalUsers: totalUsers.length,
      totalRevenue,
      ordersByStatus,
      recentOrders: totalOrders.slice(0, 5),
    };
  },
});

// Quản lý sản phẩm
export const getAllProducts = query({
  args: {},
  handler: async (ctx) => {
    await requireAdmin(ctx);
    
    const products = await ctx.db.query("products").collect();
    const productsWithCategory = await Promise.all(
      products.map(async (product) => {
        const category = await ctx.db.get(product.categoryId);
        return { ...product, category };
      })
    );
    
    return productsWithCategory;
  },
});

export const createProduct = mutation({
  args: {
    name: v.string(),
    description: v.optional(v.string()),
    categoryId: v.id("categories"),
    basePrice: v.number(),
    imageUrl: v.optional(v.string()),
    isAvailable: v.boolean(),
    ingredients: v.optional(v.array(v.string())),
    nutritionInfo: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    
    const slug = args.name.toLowerCase()
      .replace(/[^a-z0-9\s-]/g, '')
      .replace(/\s+/g, '-')
      .trim();
    
    return await ctx.db.insert("products", {
      ...args,
      slug,
    });
  },
});

export const updateProduct = mutation({
  args: {
    productId: v.id("products"),
    name: v.optional(v.string()),
    description: v.optional(v.string()),
    categoryId: v.optional(v.id("categories")),
    basePrice: v.optional(v.number()),
    imageUrl: v.optional(v.string()),
    isAvailable: v.optional(v.boolean()),
    ingredients: v.optional(v.array(v.string())),
    nutritionInfo: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    
    const { productId, ...updates } = args;
    
    // Cập nhật slug nếu tên thay đổi
    if (updates.name) {
      const slug = updates.name.toLowerCase()
        .replace(/[^a-z0-9\s-]/g, '')
        .replace(/\s+/g, '-')
        .trim();
      (updates as any).slug = slug;
    }
    
    await ctx.db.patch(productId, updates);
  },
});

export const deleteProduct = mutation({
  args: { productId: v.id("products") },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    await ctx.db.delete(args.productId);
  },
});

// Quản lý danh mục
export const getAllCategories = query({
  args: {},
  handler: async (ctx) => {
    await requireAdmin(ctx);
    return await ctx.db.query("categories").collect();
  },
});

export const createCategory = mutation({
  args: {
    name: v.string(),
    description: v.optional(v.string()),
    imageUrl: v.optional(v.string()),
    isActive: v.boolean(),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    
    const slug = args.name.toLowerCase()
      .replace(/[^a-z0-9\s-]/g, '')
      .replace(/\s+/g, '-')
      .trim();
    
    return await ctx.db.insert("categories", {
      ...args,
      slug,
    });
  },
});

export const updateCategory = mutation({
  args: {
    categoryId: v.id("categories"),
    name: v.optional(v.string()),
    description: v.optional(v.string()),
    imageUrl: v.optional(v.string()),
    isActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    
    const { categoryId, ...updates } = args;
    
    if (updates.name) {
      const slug = updates.name.toLowerCase()
        .replace(/[^a-z0-9\s-]/g, '')
        .replace(/\s+/g, '-')
        .trim();
      (updates as any).slug = slug;
    }
    
    await ctx.db.patch(categoryId, updates);
  },
});

export const deleteCategory = mutation({
  args: { categoryId: v.id("categories") },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    
    // Kiểm tra xem có sản phẩm nào đang sử dụng danh mục này không
    const products = await ctx.db
      .query("products")
      .withIndex("by_category", (q) => q.eq("categoryId", args.categoryId))
      .collect();
    
    if (products.length > 0) {
      throw new Error("Không thể xóa danh mục đang có sản phẩm");
    }
    
    await ctx.db.delete(args.categoryId);
  },
});

// Quản lý đơn hàng
export const getAllOrders = query({
  args: {},
  handler: async (ctx) => {
    await requireAdmin(ctx);
    
    const orders = await ctx.db.query("orders").order("desc").collect();
    
    const ordersWithDetails = await Promise.all(
      orders.map(async (order) => {
        const user = order.userId ? await ctx.db.get(order.userId) : null;
        const orderItems = await ctx.db
          .query("orderItems")
          .withIndex("by_order", (q) => q.eq("orderId", order._id))
          .collect();
        
        return {
          ...order,
          user,
          itemCount: orderItems.length,
        };
      })
    );
    
    return ordersWithDetails;
  },
});

export const updateOrderStatus = mutation({
  args: {
    orderId: v.id("orders"),
    status: v.string(),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    
    await ctx.db.patch(args.orderId, {
      orderStatus: args.status,
    });
  },
});

// Upload file
export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    await requireAdmin(ctx);
    return await ctx.storage.generateUploadUrl();
  },
});

// Seed data function
export const seedData = mutation({
  args: {},
  handler: async (ctx) => {
    // Tạo danh mục
    const categories = [
      {
        name: "Trà Sữa",
        description: "Trà sữa thơm ngon, đậm đà",
        slug: "tra-sua",
        isActive: true,
      },
      {
        name: "Chè",
        description: "Chè truyền thống Việt Nam",
        slug: "che",
        isActive: true,
      },
      {
        name: "Nước Ép",
        description: "Nước ép trái cây tươi ngon",
        slug: "nuoc-ep",
        isActive: true,
      },
      {
        name: "Cà Phê",
        description: "Cà phê rang xay thơm ngon",
        slug: "ca-phe",
        isActive: true,
      },
    ];

    const categoryIds = [];
    for (const category of categories) {
      const existing = await ctx.db
        .query("categories")
        .withIndex("by_slug", (q) => q.eq("slug", category.slug))
        .first();
      
      if (!existing) {
        const id = await ctx.db.insert("categories", category);
        categoryIds.push(id);
      } else {
        categoryIds.push(existing._id);
      }
    }

    // Tạo sản phẩm
    const products = [
      {
        name: "Trà Sữa Truyền Thống",
        description: "Trà sữa đậm đà với hương vị truyền thống",
        categoryId: categoryIds[0],
        basePrice: 35000,
        isAvailable: true,
        slug: "tra-sua-truyen-thong",
        ingredients: ["Trà đen", "Sữa tươi", "Đường"],
      },
      {
        name: "Trà Sữa Matcha",
        description: "Trà sữa matcha Nhật Bản thơm ngon",
        categoryId: categoryIds[0],
        basePrice: 45000,
        isAvailable: true,
        slug: "tra-sua-matcha",
        ingredients: ["Matcha", "Sữa tươi", "Đường"],
      },
      {
        name: "Chè Đậu Đỏ",
        description: "Chè đậu đỏ nước cốt dừa thơm ngon",
        categoryId: categoryIds[1],
        basePrice: 25000,
        isAvailable: true,
        slug: "che-dau-do",
        ingredients: ["Đậu đỏ", "Nước cốt dừa", "Đường phèn"],
      },
      {
        name: "Nước Ép Cam",
        description: "Nước ép cam tươi 100% tự nhiên",
        categoryId: categoryIds[2],
        basePrice: 30000,
        isAvailable: true,
        slug: "nuoc-ep-cam",
        ingredients: ["Cam tươi"],
      },
      {
        name: "Cà Phê Đen",
        description: "Cà phê đen đậm đà, thơm ngon",
        categoryId: categoryIds[3],
        basePrice: 20000,
        isAvailable: true,
        slug: "ca-phe-den",
        ingredients: ["Cà phê rang xay"],
      },
    ];

    const productIds = [];
    for (const product of products) {
      const existing = await ctx.db
        .query("products")
        .withIndex("by_slug", (q) => q.eq("slug", product.slug))
        .first();
      
      if (!existing) {
        const id = await ctx.db.insert("products", product);
        productIds.push(id);
      } else {
        productIds.push(existing._id);
      }
    }

    // Tạo tùy chọn sản phẩm
    const options = [
      // Size options
      { productId: productIds[0], optionGroup: "size", optionValue: "M", priceAdjustment: 0, isDefault: true },
      { productId: productIds[0], optionGroup: "size", optionValue: "L", priceAdjustment: 5000, isDefault: false },
      { productId: productIds[1], optionGroup: "size", optionValue: "M", priceAdjustment: 0, isDefault: true },
      { productId: productIds[1], optionGroup: "size", optionValue: "L", priceAdjustment: 5000, isDefault: false },
      
      // Sugar options
      { productId: productIds[0], optionGroup: "sugar", optionValue: "50%", priceAdjustment: 0, isDefault: false },
      { productId: productIds[0], optionGroup: "sugar", optionValue: "70%", priceAdjustment: 0, isDefault: true },
      { productId: productIds[0], optionGroup: "sugar", optionValue: "100%", priceAdjustment: 0, isDefault: false },
      
      // Ice options
      { productId: productIds[0], optionGroup: "ice", optionValue: "Ít đá", priceAdjustment: 0, isDefault: false },
      { productId: productIds[0], optionGroup: "ice", optionValue: "Bình thường", priceAdjustment: 0, isDefault: true },
      { productId: productIds[0], optionGroup: "ice", optionValue: "Nhiều đá", priceAdjustment: 0, isDefault: false },
    ];

    for (const option of options) {
      const existing = await ctx.db
        .query("productOptions")
        .withIndex("by_product", (q) => q.eq("productId", option.productId))
        .filter((q) => 
          q.and(
            q.eq(q.field("optionGroup"), option.optionGroup),
            q.eq(q.field("optionValue"), option.optionValue)
          )
        )
        .first();
      
      if (!existing) {
        await ctx.db.insert("productOptions", option);
      }
    }

    // Tạo topping
    const toppings = [
      { name: "Trân châu đen", price: 5000, isAvailable: true },
      { name: "Trân châu trắng", price: 5000, isAvailable: true },
      { name: "Thạch dừa", price: 7000, isAvailable: true },
      { name: "Pudding", price: 8000, isAvailable: true },
    ];

    const toppingIds = [];
    for (const topping of toppings) {
      const existing = await ctx.db
        .query("toppings")
        .filter((q) => q.eq(q.field("name"), topping.name))
        .first();
      
      if (!existing) {
        const id = await ctx.db.insert("toppings", topping);
        toppingIds.push(id);
      } else {
        toppingIds.push(existing._id);
      }
    }

    // Liên kết sản phẩm với topping
    for (const productId of productIds.slice(0, 2)) { // Chỉ trà sữa có topping
      for (const toppingId of toppingIds) {
        const existing = await ctx.db
          .query("productToppings")
          .withIndex("by_product", (q) => q.eq("productId", productId))
          .filter((q) => q.eq(q.field("toppingId"), toppingId))
          .first();
        
        if (!existing) {
          await ctx.db.insert("productToppings", {
            productId,
            toppingId,
          });
        }
      }
    }

    return { success: true, message: "Dữ liệu mẫu đã được tạo thành công!" };
  },
});
