import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Lấy tất cả danh mục
export const getCategories = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("categories")
      .filter((q) => q.eq(q.field("isActive"), true))
      .collect();
  },
});

// Lấy sản phẩm theo danh mục
export const getProductsByCategory = query({
  args: { categoryId: v.id("categories") },
  handler: async (ctx, args) => {
    const products = await ctx.db
      .query("products")
      .withIndex("by_category", (q) => q.eq("categoryId", args.categoryId))
      .filter((q) => q.eq(q.field("isAvailable"), true))
      .collect();

    // Lấy thêm thông tin danh mục
    const category = await ctx.db.get(args.categoryId);

    return {
      category,
      products,
    };
  },
});

// Lấy chi tiết sản phẩm
export const getProductDetail = query({
  args: { productId: v.id("products") },
  handler: async (ctx, args) => {
    const product = await ctx.db.get(args.productId);
    if (!product) return null;

    // Lấy các tùy chọn của sản phẩm
    const options = await ctx.db
      .query("productOptions")
      .withIndex("by_product", (q) => q.eq("productId", args.productId))
      .collect();

    // Lấy các topping có thể chọn
    const productToppings = await ctx.db
      .query("productToppings")
      .withIndex("by_product", (q) => q.eq("productId", args.productId))
      .collect();

    const toppingsResults = await Promise.all(
      productToppings.map(async (pt) => {
        const topping = await ctx.db.get(pt.toppingId);
        return topping;
      })
    );
    const toppings = toppingsResults.filter(Boolean);

    // Lấy đánh giá
    const reviews = await ctx.db
      .query("reviews")
      .withIndex("by_product", (q) => q.eq("productId", args.productId))
      .filter((q) => q.eq(q.field("isApproved"), true))
      .collect();

    // Tính điểm trung bình
    const averageRating = reviews.length > 0 
      ? reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length
      : 0;

    return {
      product,
      options: options.reduce((acc, option) => {
        if (!acc[option.optionGroup]) {
          acc[option.optionGroup] = [];
        }
        acc[option.optionGroup].push(option);
        return acc;
      }, {} as Record<string, typeof options>),
      toppings: toppings,
      reviews,
      averageRating,
      reviewCount: reviews.length,
    };
  },
});

// Tìm kiếm sản phẩm
export const searchProducts = query({
  args: { searchTerm: v.string() },
  handler: async (ctx, args) => {
    const products = await ctx.db.query("products").collect();
    
    return products.filter((product) =>
      product.name.toLowerCase().includes(args.searchTerm.toLowerCase()) ||
      (product.description && product.description.toLowerCase().includes(args.searchTerm.toLowerCase()))
    );
  },
});

// Lấy sản phẩm nổi bật (có thể dựa trên số lượng bán hoặc đánh giá)
export const getFeaturedProducts = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("products")
      .filter((q) => q.eq(q.field("isAvailable"), true))
      .order("desc")
      .take(8);
  },
});

// Thêm đánh giá sản phẩm
export const addReview = mutation({
  args: {
    productId: v.id("products"),
    rating: v.number(),
    comment: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Bạn cần đăng nhập để đánh giá sản phẩm");
    }

    return await ctx.db.insert("reviews", {
      productId: args.productId,
      userId: userId,
      rating: args.rating,
      comment: args.comment,
      isApproved: false, // Cần admin duyệt
    });
  },
});
