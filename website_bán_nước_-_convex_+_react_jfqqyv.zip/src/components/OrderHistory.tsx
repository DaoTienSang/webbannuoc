import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState } from "react";
import { Id } from "../../convex/_generated/dataModel";

interface OrderHistoryProps {
  onBack: () => void;
}

export function OrderHistory({ onBack }: OrderHistoryProps) {
  const orders = useQuery(api.orders.getUserOrders);
  const [selectedOrderId, setSelectedOrderId] = useState<Id<"orders"> | null>(null);
  const orderDetail = useQuery(
    api.orders.getOrderDetail,
    selectedOrderId ? { orderId: selectedOrderId } : "skip"
  );

  if (!orders) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "confirmed":
        return "bg-blue-100 text-blue-800";
      case "preparing":
        return "bg-purple-100 text-purple-800";
      case "shipping":
        return "bg-indigo-100 text-indigo-800";
      case "delivered":
        return "bg-green-100 text-green-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "pending":
        return "Chờ xác nhận";
      case "confirmed":
        return "Đã xác nhận";
      case "preparing":
        return "Đang chuẩn bị";
      case "shipping":
        return "Đang giao hàng";
      case "delivered":
        return "Đã giao hàng";
      case "cancelled":
        return "Đã hủy";
      default:
        return status;
    }
  };

  if (selectedOrderId && orderDetail) {
    return (
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setSelectedOrderId(null)}
            className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            ← Quay lại danh sách
          </button>
          <h1 className="text-2xl font-bold">Chi tiết đơn hàng</h1>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border">
          {/* Order Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <h3 className="font-semibold mb-2">Thông tin đơn hàng</h3>
              <div className="space-y-1 text-sm">
                <div>Mã đơn: #{orderDetail._id.slice(-8)}</div>
                <div>Ngày đặt: {new Date(orderDetail._creationTime).toLocaleDateString('vi-VN')}</div>
                <div>
                  Trạng thái: 
                  <span className={`ml-2 px-2 py-1 rounded-full text-xs ${getStatusColor(orderDetail.orderStatus)}`}>
                    {getStatusText(orderDetail.orderStatus)}
                  </span>
                </div>
                <div>Thanh toán: {orderDetail.paymentMethod}</div>
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2">Địa chỉ giao hàng</h3>
              <div className="text-sm text-gray-600">
                {orderDetail.shippingAddress}
              </div>
              {orderDetail.notes && (
                <div className="mt-2">
                  <span className="font-medium">Ghi chú:</span>
                  <div className="text-sm text-gray-600">{orderDetail.notes}</div>
                </div>
              )}
            </div>
          </div>

          {/* Order Items */}
          <div>
            <h3 className="font-semibold mb-4">Sản phẩm đã đặt</h3>
            <div className="space-y-4">
              {orderDetail.items.map((item) => (
                <div key={item._id} className="flex items-start space-x-4 p-4 border rounded-lg">
                  <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center">
                    <span className="text-2xl">
                      {item.product?.name.includes("Trà Sữa") && "🧋"}
                      {item.product?.name.includes("Chè") && "🍮"}
                      {item.product?.name.includes("Nước Ép") && "🥤"}
                      {item.product?.name.includes("Cà Phê") && "☕"}
                    </span>
                  </div>
                  
                  <div className="flex-1">
                    <h4 className="font-medium">{item.product?.name}</h4>
                    
                    {/* Options */}
                    <div className="text-sm text-gray-600 mt-1">
                      {item.selectedOptions.size && (
                        <span className="mr-3">Size: {item.selectedOptions.size}</span>
                      )}
                      {item.selectedOptions.sugar && (
                        <span className="mr-3">Đường: {item.selectedOptions.sugar}</span>
                      )}
                      {item.selectedOptions.ice && (
                        <span>Đá: {item.selectedOptions.ice}</span>
                      )}
                    </div>

                    {/* Toppings */}
                    {item.toppings.length > 0 && (
                      <div className="text-sm text-gray-600 mt-1">
                        Topping: {item.toppings.map(t => `${t.topping?.name} (${t.quantity})`).join(", ")}
                      </div>
                    )}

                    <div className="flex items-center justify-between mt-2">
                      <span className="text-sm">Số lượng: {item.quantity}</span>
                      <span className="font-medium">
                        {item.subtotal.toLocaleString('vi-VN')}đ
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Order Summary */}
          <div className="border-t pt-4 mt-6">
            <div className="space-y-2 max-w-sm ml-auto">
              <div className="flex justify-between">
                <span>Tạm tính:</span>
                <span>{orderDetail.totalAmount.toLocaleString('vi-VN')}đ</span>
              </div>
              <div className="flex justify-between">
                <span>Phí vận chuyển:</span>
                <span>{orderDetail.shippingFee.toLocaleString('vi-VN')}đ</span>
              </div>
              {orderDetail.discountAmount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Giảm giá:</span>
                  <span>-{orderDetail.discountAmount.toLocaleString('vi-VN')}đ</span>
                </div>
              )}
              <div className="flex justify-between font-bold text-lg border-t pt-2">
                <span>Tổng cộng:</span>
                <span className="text-blue-600">
                  {orderDetail.finalAmount.toLocaleString('vi-VN')}đ
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <button
          onClick={onBack}
          className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
        >
          ← Quay lại
        </button>
        <h1 className="text-2xl font-bold">Lịch sử đơn hàng</h1>
      </div>

      {orders.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">📋</div>
          <h2 className="text-xl font-semibold mb-2">Chưa có đơn hàng nào</h2>
          <p className="text-gray-600 mb-6">Bạn chưa đặt đơn hàng nào</p>
          <button
            onClick={onBack}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors"
          >
            Bắt đầu mua sắm
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((order) => (
            <div
              key={order._id}
              className="bg-white p-6 rounded-lg shadow-sm border hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => setSelectedOrderId(order._id)}
            >
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-semibold">Đơn hàng #{order._id.slice(-8)}</h3>
                  <p className="text-sm text-gray-600">
                    {new Date(order._creationTime).toLocaleDateString('vi-VN')}
                  </p>
                </div>
                <div className="text-right">
                  <div className="font-bold text-blue-600">
                    {order.finalAmount.toLocaleString('vi-VN')}đ
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(order.orderStatus)}`}>
                    {getStatusText(order.orderStatus)}
                  </span>
                </div>
              </div>
              
              <div className="text-sm text-gray-600">
                <div>Thanh toán: {order.paymentMethod}</div>
                <div className="mt-1 truncate">Địa chỉ: {order.shippingAddress}</div>
              </div>
              
              <div className="mt-4 text-sm text-blue-600 hover:text-blue-700">
                Xem chi tiết →
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
