import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";

interface SearchBarProps {
  onProductClick: (productId: Id<"products">) => void;
}

export function SearchBar({ onProductClick }: SearchBarProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  
  const searchResults = useQuery(
    api.products.searchProducts,
    searchTerm.length >= 2 ? { searchTerm } : "skip"
  );

  const handleSearch = (value: string) => {
    setSearchTerm(value);
    setIsSearching(value.length >= 2);
  };

  const handleProductSelect = (productId: Id<"products">) => {
    setSearchTerm("");
    setIsSearching(false);
    onProductClick(productId);
  };

  return (
    <div className="relative">
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <svg className="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => handleSearch(e.target.value)}
          placeholder="Tìm kiếm sản phẩm..."
          className="search-input"
        />
      </div>

      {/* Search Results Dropdown */}
      {isSearching && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white/95 backdrop-blur-sm rounded-xl shadow-2xl border border-white/20 max-h-96 overflow-y-auto z-50 animate-fade-in-up">
          {!searchResults ? (
            <div className="p-4 text-center">
              <div className="spinner mx-auto mb-2"></div>
              <p className="text-gray-600">Đang tìm kiếm...</p>
            </div>
          ) : searchResults.length === 0 ? (
            <div className="p-4 text-center text-gray-600">
              Không tìm thấy sản phẩm nào
            </div>
          ) : (
            <div className="p-2">
              {searchResults.map((product) => (
                <button
                  key={product._id}
                  onClick={() => handleProductSelect(product._id)}
                  className="w-full p-3 hover:bg-blue-50 rounded-lg transition-colors text-left flex items-center space-x-3"
                >
                  <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                    <span className="text-xl">
                      {product.name.includes("Trà Sữa") && "🧋"}
                      {product.name.includes("Chè") && "🍮"}
                      {product.name.includes("Nước Ép") && "🥤"}
                      {product.name.includes("Cà Phê") && "☕"}
                    </span>
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium">{product.name}</h4>
                    <p className="text-sm text-gray-600 truncate">{product.description}</p>
                    <p className="text-sm font-bold text-blue-600">
                      {product.basePrice.toLocaleString('vi-VN')}đ
                    </p>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
