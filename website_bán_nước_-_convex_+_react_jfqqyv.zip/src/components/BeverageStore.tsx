import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { ProductGrid } from "./ProductGrid";
import { ProductDetail } from "./ProductDetail";
import { Cart } from "./Cart";
import { OrderHistory } from "./OrderHistory";
import { Wishlist } from "./Wishlist";
import { SearchBar } from "./SearchBar";
import { Id } from "../../convex/_generated/dataModel";

type View = "home" | "category" | "product" | "cart" | "orders" | "wishlist";

export function BeverageStore() {
  const [currentView, setCurrentView] = useState<View>("home");
  const [selectedCategoryId, setSelectedCategoryId] = useState<Id<"categories"> | null>(null);
  const [selectedProductId, setSelectedProductId] = useState<Id<"products"> | null>(null);
  
  const categories = useQuery(api.products.getCategories);
  const cart = useQuery(api.cart.getCart);
  const wishlist = useQuery(api.wishlist.getWishlist);
  const seedData = useMutation(api.admin.seedData);

  const cartItemCount = cart?.reduce((sum, item) => sum + item.quantity, 0) || 0;
  const wishlistCount = wishlist?.length || 0;

  const handleSeedData = async () => {
    try {
      await seedData({});
      alert("Dữ liệu mẫu đã được thêm thành công!");
    } catch (error) {
      console.error("Lỗi khi thêm dữ liệu mẫu:", error);
    }
  };

  const handleProductClick = (productId: Id<"products">) => {
    setSelectedProductId(productId);
    setCurrentView("product");
  };

  const renderContent = () => {
    switch (currentView) {
      case "home":
        return (
          <div className="space-y-8 animate-fade-in-up">
            {/* Hero Section */}
            <div className="relative overflow-hidden bg-gradient-to-r from-blue-500 via-cyan-500 to-blue-600 text-white p-8 rounded-3xl shadow-2xl">
              <div className="absolute inset-0 bg-black/10"></div>
              <div className="relative z-10">
                <h1 className="text-4xl md:text-5xl font-bold mb-4 animate-slide-in">
                  🧋 Nước Ngon Store
                </h1>
                <p className="text-xl mb-6 animate-slide-in" style={{ animationDelay: '0.2s' }}>
                  Trà sữa, chè, nước ép tươi ngon mỗi ngày
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <button
                    onClick={handleSeedData}
                    className="bg-white/20 backdrop-blur-sm text-white px-6 py-3 rounded-xl font-semibold hover:bg-white/30 transition-all duration-300 shadow-lg animate-bounce-in"
                  >
                    ✨ Thêm dữ liệu mẫu
                  </button>
                  <SearchBar onProductClick={handleProductClick} />
                </div>
              </div>
              <div className="absolute top-4 right-4 text-6xl animate-float">🌟</div>
              <div className="absolute bottom-4 left-4 text-4xl animate-float" style={{ animationDelay: '1s' }}>✨</div>
            </div>

            {/* Categories */}
            <div>
              <h2 className="text-3xl font-bold mb-6 text-blue-800 text-center">
                🎯 Danh mục sản phẩm
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {categories?.map((category, index) => (
                  <button
                    key={category._id}
                    onClick={() => {
                      setSelectedCategoryId(category._id);
                      setCurrentView("category");
                    }}
                    className="category-card p-6 text-center animate-bounce-in"
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <div className="text-4xl mb-3 animate-float">
                      {category.name === "Trà Sữa" && "🧋"}
                      {category.name === "Chè" && "🍮"}
                      {category.name === "Nước Ép" && "🥤"}
                      {category.name === "Cà Phê" && "☕"}
                    </div>
                    <h3 className="font-bold text-lg text-blue-800">{category.name}</h3>
                    <p className="text-sm text-blue-600 mt-2">{category.description}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Featured Products */}
            <div className="text-center">
              <h2 className="text-3xl font-bold mb-6 text-blue-800">
                🔥 Sản phẩm nổi bật
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[
                  { emoji: "🧋", title: "Trà Sữa Premium", desc: "Hương vị đậm đà, thơm ngon" },
                  { emoji: "🍮", title: "Chè Truyền Thống", desc: "Công thức gia truyền" },
                  { emoji: "🥤", title: "Nước Ép Tươi", desc: "100% trái cây tự nhiên" }
                ].map((item, index) => (
                  <div 
                    key={index}
                    className="category-card p-6 text-center animate-bounce-in"
                    style={{ animationDelay: `${index * 0.2}s` }}
                  >
                    <div className="text-5xl mb-4 animate-float">{item.emoji}</div>
                    <h3 className="font-bold text-lg text-blue-800 mb-2">{item.title}</h3>
                    <p className="text-blue-600">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case "category":
        return selectedCategoryId ? (
          <ProductGrid 
            categoryId={selectedCategoryId}
            onProductClick={handleProductClick}
            onBack={() => setCurrentView("home")}
          />
        ) : null;

      case "product":
        return selectedProductId ? (
          <ProductDetail
            productId={selectedProductId}
            onBack={() => setCurrentView("category")}
          />
        ) : null;

      case "cart":
        return <Cart onBack={() => setCurrentView("home")} />;

      case "orders":
        return <OrderHistory onBack={() => setCurrentView("home")} />;

      case "wishlist":
        return <Wishlist onBack={() => setCurrentView("home")} onProductClick={handleProductClick} />;

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen">
      <div className="max-w-4xl mx-auto p-4">
        {/* Navigation */}
        <nav className="nav-glass flex items-center justify-between mb-8 p-4 animate-slide-in">
          <div className="flex space-x-2">
            <button
              onClick={() => setCurrentView("home")}
              className={`px-4 py-2 rounded-xl font-medium transition-all duration-300 ${
                currentView === "home" 
                  ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg" 
                  : "text-blue-700 hover:bg-blue-100"
              }`}
            >
              🏠 Trang chủ
            </button>
            <button
              onClick={() => setCurrentView("orders")}
              className={`px-4 py-2 rounded-xl font-medium transition-all duration-300 ${
                currentView === "orders" 
                  ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg" 
                  : "text-blue-700 hover:bg-blue-100"
              }`}
            >
              📋 Đơn hàng
            </button>
          </div>
          
          <div className="flex space-x-3">
            <button
              onClick={() => setCurrentView("wishlist")}
              className="relative px-4 py-2 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-xl font-medium hover:from-pink-600 hover:to-rose-600 transition-all duration-300 shadow-lg transform hover:scale-105"
            >
              💝 Yêu thích
              {wishlistCount > 0 && (
                <span className="notification-badge">
                  {wishlistCount}
                </span>
              )}
            </button>
            
            <button
              onClick={() => setCurrentView("cart")}
              className="relative px-4 py-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl font-medium hover:from-green-600 hover:to-emerald-600 transition-all duration-300 shadow-lg transform hover:scale-105"
            >
              🛒 Giỏ hàng
              {cartItemCount > 0 && (
                <span className="notification-badge">
                  {cartItemCount}
                </span>
              )}
            </button>
          </div>
        </nav>

        {/* Main Content */}
        {renderContent()}
      </div>
    </div>
  );
}
