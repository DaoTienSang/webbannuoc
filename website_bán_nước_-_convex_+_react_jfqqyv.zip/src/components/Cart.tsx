import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { toast } from "sonner";

interface CartProps {
  onBack: () => void;
}

export function Cart({ onBack }: CartProps) {
  const cart = useQuery(api.cart.getCart);
  const updateCartItem = useMutation(api.cart.updateCartItem);
  const removeFromCart = useMutation(api.cart.removeFromCart);
  const createOrder = useMutation(api.orders.createOrder);

  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [shippingAddress, setShippingAddress] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("COD");
  const [notes, setNotes] = useState("");

  if (!cart) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const totalAmount = cart.reduce((sum, item) => sum + item.totalPrice, 0);
  const shippingFee = totalAmount >= 200000 ? 0 : 25000;
  const finalAmount = totalAmount + shippingFee;

  const handleUpdateQuantity = async (cartItemId: string, newQuantity: number) => {
    try {
      await updateCartItem({ cartItemId: cartItemId as Id<"cartItems">, quantity: newQuantity });
    } catch (error) {
      toast.error("Có lỗi xảy ra khi cập nhật giỏ hàng");
    }
  };

  const handleRemoveItem = async (cartItemId: string) => {
    try {
      await removeFromCart({ cartItemId: cartItemId as Id<"cartItems"> });
      toast.success("Đã xóa sản phẩm khỏi giỏ hàng");
    } catch (error) {
      toast.error("Có lỗi xảy ra khi xóa sản phẩm");
    }
  };

  const handleCheckout = async () => {
    if (!shippingAddress.trim()) {
      toast.error("Vui lòng nhập địa chỉ giao hàng");
      return;
    }

    setIsCheckingOut(true);
    try {
      await createOrder({
        shippingAddress,
        paymentMethod,
        notes: notes || undefined,
      });
      toast.success("Đặt hàng thành công!");
      onBack();
    } catch (error) {
      toast.error("Có lỗi xảy ra khi đặt hàng");
      console.error(error);
    } finally {
      setIsCheckingOut(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <button
          onClick={onBack}
          className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
        >
          ← Quay lại
        </button>
        <h1 className="text-2xl font-bold">Giỏ hàng</h1>
      </div>

      {cart.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">🛒</div>
          <h2 className="text-xl font-semibold mb-2">Giỏ hàng trống</h2>
          <p className="text-gray-600 mb-6">Hãy thêm một số sản phẩm vào giỏ hàng của bạn</p>
          <button
            onClick={onBack}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors"
          >
            Tiếp tục mua sắm
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cart.map((item) => (
              <div key={item._id} className="bg-white p-6 rounded-lg shadow-sm border">
                <div className="flex items-start space-x-4">
                  <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center">
                    <span className="text-2xl">
                      {item.product?.name.includes("Trà Sữa") && "🧋"}
                      {item.product?.name.includes("Chè") && "🍮"}
                      {item.product?.name.includes("Nước Ép") && "🥤"}
                      {item.product?.name.includes("Cà Phê") && "☕"}
                    </span>
                  </div>
                  
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg">{item.product?.name}</h3>
                    
                    {/* Options */}
                    <div className="text-sm text-gray-600 mt-1">
                      {item.selectedOptions.size && (
                        <span className="mr-3">Size: {item.selectedOptions.size}</span>
                      )}
                      {item.selectedOptions.sugar && (
                        <span className="mr-3">Đường: {item.selectedOptions.sugar}</span>
                      )}
                      {item.selectedOptions.ice && (
                        <span>Đá: {item.selectedOptions.ice}</span>
                      )}
                    </div>

                    {/* Toppings */}
                    {item.toppings.length > 0 && (
                      <div className="text-sm text-gray-600 mt-1">
                        Topping: {item.toppings.map(t => `${t?.name} (${t.quantity})`).join(", ")}
                      </div>
                    )}

                    <div className="flex items-center justify-between mt-4">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handleUpdateQuantity(item._id, item.quantity - 1)}
                          className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center"
                        >
                          -
                        </button>
                        <span className="w-8 text-center font-semibold">{item.quantity}</span>
                        <button
                          onClick={() => handleUpdateQuantity(item._id, item.quantity + 1)}
                          className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center"
                        >
                          +
                        </button>
                      </div>
                      
                      <div className="text-right">
                        <div className="font-bold text-blue-600">
                          {item.totalPrice.toLocaleString('vi-VN')}đ
                        </div>
                        <button
                          onClick={() => handleRemoveItem(item._id)}
                          className="text-red-500 hover:text-red-700 text-sm"
                        >
                          Xóa
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Checkout Form */}
          <div className="bg-white p-6 rounded-lg shadow-sm border h-fit">
            <h2 className="text-xl font-bold mb-4">Thông tin đặt hàng</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Địa chỉ giao hàng *
                </label>
                <textarea
                  value={shippingAddress}
                  onChange={(e) => setShippingAddress(e.target.value)}
                  placeholder="Nhập địa chỉ giao hàng đầy đủ..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  rows={3}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Phương thức thanh toán
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="COD">Thanh toán khi nhận hàng (COD)</option>
                  <option value="VNPay">VNPay</option>
                  <option value="Momo">Momo</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Ghi chú (tùy chọn)
                </label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Ghi chú cho đơn hàng..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  rows={2}
                />
              </div>
            </div>

            {/* Order Summary */}
            <div className="border-t pt-4 mt-6 space-y-2">
              <div className="flex justify-between">
                <span>Tạm tính:</span>
                <span>{totalAmount.toLocaleString('vi-VN')}đ</span>
              </div>
              <div className="flex justify-between">
                <span>Phí vận chuyển:</span>
                <span>
                  {shippingFee === 0 ? (
                    <span className="text-green-600">Miễn phí</span>
                  ) : (
                    `${shippingFee.toLocaleString('vi-VN')}đ`
                  )}
                </span>
              </div>
              {totalAmount < 200000 && (
                <div className="text-sm text-gray-600">
                  Mua thêm {(200000 - totalAmount).toLocaleString('vi-VN')}đ để được miễn phí ship
                </div>
              )}
              <div className="flex justify-between font-bold text-lg border-t pt-2">
                <span>Tổng cộng:</span>
                <span className="text-blue-600">{finalAmount.toLocaleString('vi-VN')}đ</span>
              </div>
            </div>

            <button
              onClick={handleCheckout}
              disabled={isCheckingOut || !shippingAddress.trim()}
              className="w-full mt-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
            >
              {isCheckingOut ? "Đang xử lý..." : "Đặt hàng"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
