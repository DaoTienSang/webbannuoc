import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { toast } from "sonner";

interface ProductDetailProps {
  productId: Id<"products">;
  onBack: () => void;
}

export function ProductDetail({ productId, onBack }: ProductDetailProps) {
  const data = useQuery(api.products.getProductDetail, { productId });
  const addToCart = useMutation(api.cart.addToCart);

  const [quantity, setQuantity] = useState(1);
  const [selectedOptions, setSelectedOptions] = useState<{
    size?: string;
    sugar?: string;
    ice?: string;
  }>({});
  const [selectedToppings, setSelectedToppings] = useState<Record<string, number>>({});

  // Set default options
  useEffect(() => {
    if (data && Object.keys(data.options).length > 0) {
      const defaults: typeof selectedOptions = {};
      Object.entries(data.options).forEach(([group, groupOptions]) => {
        const defaultOption = groupOptions.find(opt => opt.isDefault);
        if (defaultOption) {
          defaults[group as keyof typeof defaults] = defaultOption.optionValue;
        }
      });
      setSelectedOptions(defaults);
    }
  }, [data]);

  if (!data) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const { product, options, toppings, averageRating, reviewCount } = data;

  const calculatePrice = () => {
    let price = product.basePrice;
    
    // Add size adjustment
    if (selectedOptions.size && options.size) {
      const sizeOption = options.size.find(opt => opt.optionValue === selectedOptions.size);
      if (sizeOption) {
        price += sizeOption.priceAdjustment;
      }
    }

    // Add toppings price
    const toppingsPrice = Object.entries(selectedToppings).reduce((sum, [toppingId, qty]) => {
      const topping = toppings.find(t => t?._id === toppingId);
      return sum + (topping?.price || 0) * qty;
    }, 0);

    return (price + toppingsPrice) * quantity;
  };

  const handleAddToCart = async () => {
    try {
      const toppingsArray = Object.entries(selectedToppings)
        .filter(([_, qty]) => qty > 0)
        .map(([toppingId, qty]) => ({
          toppingId: toppingId as Id<"toppings">,
          quantity: qty,
        }));

      await addToCart({
        productId,
        quantity,
        selectedOptions,
        selectedToppings: toppingsArray,
      });

      toast.success("Đã thêm vào giỏ hàng!");
    } catch (error) {
      toast.error("Có lỗi xảy ra khi thêm vào giỏ hàng");
      console.error(error);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <button
          onClick={onBack}
          className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
        >
          ← Quay lại
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Product Image */}
        <div className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center">
          <span className="text-8xl">
            {product.name.includes("Trà Sữa") && "🧋"}
            {product.name.includes("Chè") && "🍮"}
            {product.name.includes("Nước Ép") && "🥤"}
            {product.name.includes("Cà Phê") && "☕"}
          </span>
        </div>

        {/* Product Info */}
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
            <p className="text-gray-600 mb-4">{product.description}</p>
            
            {/* Rating */}
            <div className="flex items-center space-x-2 mb-4">
              <div className="flex text-yellow-400">
                {[1, 2, 3, 4, 5].map((star) => (
                  <span key={star}>
                    {star <= Math.round(averageRating) ? "★" : "☆"}
                  </span>
                ))}
              </div>
              <span className="text-sm text-gray-600">
                ({reviewCount} đánh giá)
              </span>
            </div>

            {/* Ingredients */}
            {product.ingredients && (
              <div className="mb-4">
                <h3 className="font-semibold mb-2">Thành phần:</h3>
                <div className="flex flex-wrap gap-2">
                  {product.ingredients.map((ingredient, index) => (
                    <span
                      key={index}
                      className="px-2 py-1 bg-gray-100 text-gray-700 rounded-full text-sm"
                    >
                      {ingredient}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Options */}
          {Object.entries(options).map(([group, groupOptions]) => (
            <div key={group}>
              <h3 className="font-semibold mb-2 capitalize">
                {group === "size" && "Kích thước"}
                {group === "sugar" && "Độ ngọt"}
                {group === "ice" && "Lượng đá"}
              </h3>
              <div className="flex flex-wrap gap-2">
                {groupOptions.map((option) => (
                  <button
                    key={option._id}
                    onClick={() => setSelectedOptions(prev => ({
                      ...prev,
                      [group]: option.optionValue,
                    }))}
                    className={`px-3 py-2 rounded-lg border transition-colors ${
                      selectedOptions[group as keyof typeof selectedOptions] === option.optionValue
                        ? "border-blue-600 bg-blue-50 text-blue-600"
                        : "border-gray-300 hover:border-gray-400"
                    }`}
                  >
                    {option.optionValue}
                    {option.priceAdjustment > 0 && (
                      <span className="ml-1 text-sm">
                        (+{option.priceAdjustment.toLocaleString('vi-VN')}đ)
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>
          ))}

          {/* Toppings */}
          {toppings.length > 0 && (
            <div>
              <h3 className="font-semibold mb-2">Topping</h3>
              <div className="space-y-2">
                {toppings.map((topping) => topping && (
                  <div key={topping._id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <span className="font-medium">{topping.name}</span>
                      <span className="ml-2 text-blue-600">
                        +{topping.price.toLocaleString('vi-VN')}đ
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => setSelectedToppings(prev => ({
                          ...prev,
                          [topping._id]: Math.max(0, (prev[topping._id] || 0) - 1),
                        }))}
                        className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center"
                      >
                        -
                      </button>
                      <span className="w-8 text-center">
                        {selectedToppings[topping._id] || 0}
                      </span>
                      <button
                        onClick={() => setSelectedToppings(prev => ({
                          ...prev,
                          [topping._id]: (prev[topping._id] || 0) + 1,
                        }))}
                        className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center"
                      >
                        +
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Quantity and Add to Cart */}
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">Số lượng</h3>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center"
                >
                  -
                </button>
                <span className="w-12 text-center font-semibold">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center"
                >
                  +
                </button>
              </div>
            </div>

            <div className="border-t pt-4">
              <div className="flex items-center justify-between mb-4">
                <span className="text-lg font-semibold">Tổng cộng:</span>
                <span className="text-2xl font-bold text-blue-600">
                  {calculatePrice().toLocaleString('vi-VN')}đ
                </span>
              </div>
              
              <button
                onClick={handleAddToCart}
                disabled={!product.isAvailable}
                className="w-full py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
              >
                {product.isAvailable ? "Thêm vào giỏ hàng" : "Hết hàng"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
