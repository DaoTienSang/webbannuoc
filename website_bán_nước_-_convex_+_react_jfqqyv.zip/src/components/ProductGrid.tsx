import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { WishlistButton } from "./WishlistButton";

interface ProductGridProps {
  categoryId: Id<"categories">;
  onProductClick: (productId: Id<"products">) => void;
  onBack: () => void;
}

export function ProductGrid({ categoryId, onProductClick, onBack }: ProductGridProps) {
  const data = useQuery(api.products.getProductsByCategory, { categoryId });

  if (!data) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="spinner"></div>
      </div>
    );
  }

  const { category, products } = data;

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <button
          onClick={onBack}
          className="px-4 py-2 bg-white/80 backdrop-blur-sm text-blue-700 rounded-xl hover:bg-white/90 transition-all duration-300 shadow-lg border border-blue-200"
        >
          ← Quay lại
        </button>
        <div>
          <h1 className="text-3xl font-bold text-blue-800">{category?.name}</h1>
          <p className="text-blue-600">{category?.description}</p>
        </div>
      </div>

      {/* Products Grid */}
      {products.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-8xl mb-4 animate-float">📦</div>
          <p className="text-blue-600 text-xl">Chưa có sản phẩm nào trong danh mục này</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product, index) => (
            <div
              key={product._id}
              className="product-card card-hover cursor-pointer animate-bounce-in"
              style={{ animationDelay: `${index * 0.1}s` }}
              onClick={() => onProductClick(product._id)}
            >
              <div className="relative">
                <div className="aspect-square bg-gradient-to-br from-blue-50 to-cyan-50 rounded-t-2xl flex items-center justify-center">
                  <span className="text-6xl animate-float">
                    {product.name.includes("Trà Sữa") && "🧋"}
                    {product.name.includes("Chè") && "🍮"}
                    {product.name.includes("Nước Ép") && "🥤"}
                    {product.name.includes("Cà Phê") && "☕"}
                  </span>
                </div>
                
                <WishlistButton 
                  productId={product._id} 
                  className="absolute top-3 right-3 shadow-lg"
                />
              </div>
              
              <div className="p-6 space-y-3">
                <h3 className="font-bold text-lg text-blue-800">{product.name}</h3>
                <p className="text-blue-600 text-sm line-clamp-2">
                  {product.description}
                </p>
                <div className="flex items-center justify-between">
                  <span className="price-tag">
                    {product.basePrice.toLocaleString('vi-VN')}đ
                  </span>
                  <span className={product.isAvailable ? "status-available" : "status-unavailable"}>
                    {product.isAvailable ? "Còn hàng" : "Hết hàng"}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
