import { Authenticated, Unauthenticated, AuthLoading } from "convex/react";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { BeverageStore } from "./components/BeverageStore";
import { Toaster } from "sonner";

export default function App() {
  return (
    <main className="min-h-screen">
      <AuthLoading>
        <div className="flex justify-center items-center min-h-screen">
          <div className="spinner"></div>
        </div>
      </AuthLoading>
      
      <Unauthenticated>
        <div className="min-h-screen flex items-center justify-center">
          <div className="glass p-8 rounded-3xl shadow-2xl max-w-md w-full mx-4 animate-bounce-in">
            <div className="text-center mb-8">
              <div className="text-6xl mb-4 animate-float">🧋</div>
              <h1 className="text-3xl font-bold text-blue-800 mb-2">Nước Ngon Store</h1>
              <p className="text-blue-600">Đăng nhập để bắt đầu mua sắm</p>
            </div>
            <SignInForm />
          </div>
        </div>
      </Unauthenticated>
      
      <Authenticated>
        <div className="min-h-screen">
          {/* Header with Sign Out */}
          <div className="fixed top-4 right-4 z-50">
            <SignOutButton />
          </div>

          {/* Main Content */}
          <BeverageStore />
        </div>
      </Authenticated>
      
      <Toaster position="top-right" richColors />
    </main>
  );
}
